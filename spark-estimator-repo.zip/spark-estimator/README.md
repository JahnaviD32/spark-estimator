# Spark Homes — Repair Cost Estimator

A mobile-first Progressive Web App for Spark Homes' acquisition team to estimate repair costs during property walkthroughs.

## Live Demo

> Deploy `index.html` to any static host. See submission notes for the hosted URL.

## How to Run Locally

No build tools, no dependencies, no server required.

```bash
# Option 1 — just open it
open index.html

# Option 2 — serve locally (avoids some browser file:// restrictions for camera/PWA)
npx serve .
# or
python3 -m http.server 8080
```

Then open `http://localhost:8080` in Chrome (Android) or Safari (iOS).

## What's Built

### Stack
- **Vanilla HTML/CSS/JS** — zero frameworks, zero build step
- **Tailwind CSS** via CDN for utility classes
- **xlsx-js-style** via CDN for Excel export
- **JSZip** via CDN for ZIP packaging
- **Anthropic Claude Vision API** for serial number OCR on equipment photos
- **Inter** (Google Fonts) for typography

### Features
- **108 line items** across 5 sections (Interior/General, Kitchen, Bathrooms, Systems & Structure, Exterior), all priced from the official CSV
- **19 collapsible groups** — each with a "No action needed" toggle so agents can explicitly mark groups as reviewed
- **Multi-room support** — add/remove Bathroom 1/2/3, Bedroom 1/2, Living Areas freely during walkthrough
- **Per-project price overrides** — tap any unit cost to edit it; changes are isolated to that project
- **Global price schedule** — upload an updated CSV in Settings to roll new prices across all projects
- **Add / delete custom line items** per group
- **Progress bar** — counts reviewed groups (any item checked OR "no action" toggled = complete)
- **Photo capture** — `<input capture="environment">` for reliable Android camera access; photos stored as base64
- **Serial number OCR** — each photo is sent to Claude Vision to auto-extract serial numbers from HVAC, water heaters, appliances
- **ZIP export** — Excel workbook (Summary + Line Items + Photos log sheets) + all photos bundled, auto-downloads
- **PWA** — service worker via inline blob URL (works without a HTTPS server during dev), web app manifest, installable to home screen on Android and iOS
- **localStorage** — full project state persists across sessions, no backend

### Creative Addition — Deal Analyzer
Accessed via the **Deal ↗** button on every project. Agents enter ARV, purchase price, and estimated holding costs. The app calculates:
- **Projected profit** and **ROI**
- **Deal health** rating: Strong (≥20% margin) / Marginal (10–20%) / Weak (<10%), with color coding
- **Max Allowable Offer** using the 70% rule: `ARV × 70% − Repairs − Holding Costs`
- Warning flag if the purchase price exceeds the MAO
- One-tap **Share Summary** copies the deal snapshot to clipboard for texting/emailing

This is the number acquisition agents actually need at the end of a walkthrough — not just "how much will repairs cost" but "does this deal work at this price?"

## Design Decisions

**Warm, on-brand palette** instead of a generic dark UI. The background is `#F5F0EB` (warm off-white), accent is Spark's `#C2460A` orange. Cards are white with subtle warm borders. The goal was something that looks like a professional Spark-branded tool, not a developer demo.

**Room tabs stay pinned** at the top so agents can jump between rooms without losing their place. The active tab auto-scrolls into view on render.

**Running total animates** on every check/qty change via a spring CSS transition — gives agents immediate feedback that a number just changed.

**OCR is async and non-blocking** — photos appear as thumbnails immediately; the Claude Vision call runs in the background and updates the badge when done. If it fails (no network), agents can manually tap to add a serial number note.

## Known Fragile Areas

- **OCR requires network** — the Anthropic API call will fail offline. Serial number extraction degrades gracefully (manual note entry still works).
- **Large photos** — storing full-res base64 images in localStorage can hit the 5–10MB browser quota on older devices. A production version would store photos in IndexedDB or upload to S3.
- **Service worker scope** — the inline blob URL SW registers but can't cache cross-origin CDN assets. Offline mode works for the app shell and all data, but CDN scripts (Tailwind, XLSX, JSZip) require a first load with network.
- **No conflict resolution** — if two agents open the same project on different devices, last-write-wins. A real backend would handle this.

## What's Next (with 2 more days)

1. **IndexedDB for photos** — move image storage off localStorage to remove the quota ceiling
2. **Shareable project URLs** — encode project state in a URL hash so agents can hand off estimates to the office without email
3. **Contractor contact list** — tap a trade category to see saved contractor contacts for that work type
4. **Offline CDN** — inline or self-host Tailwind/XLSX/JSZip so the app is fully air-gapped offline

## AI Tools

This app was built with Claude (Anthropic). Claude wrote the full implementation from the brief and price list, including the data model, all render functions, the export pipeline, and the Deal Analyzer. The approach, architecture decisions, and UX direction were specified and iterated on by the submitter. Claude also powers the in-app serial number OCR feature at runtime.
